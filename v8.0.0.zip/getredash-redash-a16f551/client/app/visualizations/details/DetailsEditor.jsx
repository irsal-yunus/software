export default function DetailsEditor() {
  return null;
}
