# Documentation

Static documentation website, built with [Gatsby](https://www.gatsbyjs.org/) using [`@octokit/rest`](https://github.com/octokit/rest.js/) and deployed to GitHub Pages: [https://octokit.github.io/rest.js/](https://octokit.github.io/rest.js/)

## Local Development

```
npm install
cd /docs
npm install
npm start
```
